# ADSC21 Init Kit

Diesen Ordner könnt ihr als Init Kit bzw. Starter Kit für das Modul ADSC21
nutzen.

Schaut euch den dazugehörigen Screencast sowie die Seite ["Getting
Started"](https://dbu-adsc21.pages.dev/A-getting-started/00-index) im digitalen
Skript.

- Repo initialisieren & initialen Commit machen
- IDE einrichten
- Python Environment installieren

© Copyright 2025, Sebastian Seck (DBU).
